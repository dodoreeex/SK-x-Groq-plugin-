package com.mcserver.groqskript;

/**
 * A single chat message in Groq's format: a role ("system", "user", or
 * "assistant") plus the text content.
 */
public class GroqMessage {

    private final String role;
    private final String content;

    public GroqMessage(String role, String content) {
        this.role = role;
        this.content = content;
    }

    public String getRole() {
        return role;
    }

    public String getContent() {
        return content;
    }
}
