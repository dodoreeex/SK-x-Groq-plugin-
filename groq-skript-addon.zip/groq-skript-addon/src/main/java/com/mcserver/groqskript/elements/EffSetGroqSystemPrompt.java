package com.mcserver.groqskript.elements;

import ch.njol.skript.doc.Description;
import ch.njol.skript.doc.Examples;
import ch.njol.skript.doc.Name;
import ch.njol.skript.doc.Since;
import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.util.Kleenean;
import com.mcserver.groqskript.ConversationStore;
import org.bukkit.event.Event;

@Name("Set Groq System Prompt")
@Description("Sets the system prompt (behavior instructions) for a conversation (default: \"default\"). " +
        "This does not count against the message history and is sent with every request for that conversation.")
@Examples({
        "set groq system prompt to \"You are a grumpy dwarf blacksmith. Stay in character.\"",
        "set groq system prompt of \"%player%\" to \"You are a friendly quest-giver NPC.\""
})
@Since("1.0")
public class EffSetGroqSystemPrompt extends Effect {

    private Expression<String> idExpr;
    private Expression<String> promptExpr;

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] exprs, int matchedPattern, Kleenean isDelayed, ParseResult parseResult) {
        idExpr = (Expression<String>) exprs[0];
        promptExpr = (Expression<String>) exprs[1];
        return true;
    }

    @Override
    protected void execute(Event event) {
        String id = "default";
        if (idExpr != null) {
            String parsedId = idExpr.getSingle(event);
            if (parsedId != null && !parsedId.isBlank()) {
                id = parsedId;
            }
        }
        String prompt = promptExpr.getSingle(event);
        if (prompt != null) {
            ConversationStore.get(id).setSystemPrompt(prompt);
        }
    }

    @Override
    public String toString(Event event, boolean debug) {
        return "set groq system prompt";
    }
}
