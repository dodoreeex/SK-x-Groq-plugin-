package com.mcserver.groqskript;

import java.util.ArrayList;
import java.util.List;

/**
 * Holds everything remembered for one conversation id: an optional system
 * prompt, the running message history, and the outcome of the last request.
 */
public class Conversation {

    private String systemPrompt = null;
    private final List<GroqMessage> history = new ArrayList<>();
    private String lastResponse = "";
    private String lastError = "";

    public String getSystemPrompt() {
        return systemPrompt;
    }

    public void setSystemPrompt(String systemPrompt) {
        this.systemPrompt = systemPrompt;
    }

    public List<GroqMessage> getHistory() {
        return history;
    }

    public void addMessage(String role, String content) {
        history.add(new GroqMessage(role, content));
    }

    public void clearHistory() {
        history.clear();
    }

    public String getLastResponse() {
        return lastResponse;
    }

    public void setLastResponse(String lastResponse) {
        this.lastResponse = lastResponse;
    }

    public String getLastError() {
        return lastError;
    }

    public void setLastError(String lastError) {
        this.lastError = lastError;
    }

    /**
     * Keeps the history from growing forever — drops the oldest messages,
     * always in user/assistant pairs so the conversation stays coherent.
     */
    public void trimTo(int maxMessages) {
        while (history.size() > maxMessages && history.size() >= 2) {
            history.remove(0);
        }
    }
}
