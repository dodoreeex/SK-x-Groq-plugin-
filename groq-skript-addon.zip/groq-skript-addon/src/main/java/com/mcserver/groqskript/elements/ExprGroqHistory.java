package com.mcserver.groqskript.elements;

import ch.njol.skript.doc.Description;
import ch.njol.skript.doc.Examples;
import ch.njol.skript.doc.Name;
import ch.njol.skript.doc.Since;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import com.mcserver.groqskript.Conversation;
import com.mcserver.groqskript.ConversationStore;
import com.mcserver.groqskript.GroqMessage;
import org.bukkit.event.Event;

import java.util.List;

@Name("Groq History")
@Description("The full remembered message history for a conversation (default: \"default\") as a " +
        "list of strings formatted \"role: content\", oldest first. Useful for logging or debugging.")
@Examples("loop groq history of \"%player%\":\n\tbroadcast loop-value")
@Since("1.0")
public class ExprGroqHistory extends SimpleExpression<String> {

    private Expression<String> idExpr;

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] exprs, int matchedPattern, Kleenean isDelayed, ParseResult parseResult) {
        idExpr = (Expression<String>) exprs[0];
        return true;
    }

    @Override
    protected String[] get(Event event) {
        String id = "default";
        if (idExpr != null) {
            String parsedId = idExpr.getSingle(event);
            if (parsedId != null && !parsedId.isBlank()) {
                id = parsedId;
            }
        }
        Conversation conversation = ConversationStore.get(id);
        List<GroqMessage> history = conversation.getHistory();
        String[] lines = new String[history.size()];
        for (int i = 0; i < history.size(); i++) {
            GroqMessage m = history.get(i);
            lines[i] = m.getRole() + ": " + m.getContent();
        }
        return lines;
    }

    @Override
    public boolean isSingle() {
        return false;
    }

    @Override
    public Class<? extends String> getReturnType() {
        return String.class;
    }

    @Override
    public String toString(Event event, boolean debug) {
        return "groq history";
    }
}
