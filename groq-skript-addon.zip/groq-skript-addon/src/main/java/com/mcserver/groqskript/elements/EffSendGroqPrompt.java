package com.mcserver.groqskript.elements;

import ch.njol.skript.doc.Description;
import ch.njol.skript.doc.Examples;
import ch.njol.skript.doc.Name;
import ch.njol.skript.doc.Since;
import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.util.Kleenean;
import com.mcserver.groqskript.Conversation;
import com.mcserver.groqskript.ConversationStore;
import com.mcserver.groqskript.GroqApiClient;
import com.mcserver.groqskript.GroqChatPlugin;
import org.bukkit.event.Event;

@Name("Send Groq Prompt")
@Description("Sends a prompt to Groq as part of a named conversation (default: \"default\"), " +
        "remembering prior messages in that conversation for context. Blocks briefly while " +
        "waiting on the API response. Use 'last groq response' to read the result afterwards, " +
        "and 'groq error' to check whether it failed.")
@Examples({
        "send groq prompt \"Hello there!\"",
        "send groq prompt \"What's my name?\" to \"%player%\"",
        "send groq prompt message to \"%player%\" with model \"openai/gpt-oss-120b\""
})
@Since("1.0")
public class EffSendGroqPrompt extends Effect {

    private Expression<String> promptExpr;
    private Expression<String> idExpr;
    private Expression<String> modelExpr;

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] exprs, int matchedPattern, Kleenean isDelayed, ParseResult parseResult) {
        promptExpr = (Expression<String>) exprs[0];
        idExpr = (Expression<String>) exprs[1];
        modelExpr = (Expression<String>) exprs[2];
        return true;
    }

    @Override
    protected void execute(Event event) {
        String prompt = promptExpr.getSingle(event);
        if (prompt == null) {
            return;
        }
        String id = "default";
        if (idExpr != null) {
            String parsedId = idExpr.getSingle(event);
            if (parsedId != null && !parsedId.isBlank()) {
                id = parsedId;
            }
        }

        String model = GroqChatPlugin.getInstance().getDefaultModel();
        if (modelExpr != null) {
            String parsedModel = modelExpr.getSingle(event);
            if (parsedModel != null && !parsedModel.isBlank()) {
                model = parsedModel;
            }
        }

        Conversation conversation = ConversationStore.get(id);
        conversation.addMessage("user", prompt);

        GroqApiClient.Result result = GroqChatPlugin.getApiClient().chat(
                GroqChatPlugin.getInstance().getApiKey(),
                model,
                conversation.getSystemPrompt(),
                conversation.getHistory(),
                GroqChatPlugin.getInstance().getTemperature(),
                GroqChatPlugin.getInstance().getTimeoutSeconds()
        );

        if (result.success()) {
            conversation.addMessage("assistant", result.content());
            conversation.setLastResponse(result.content());
            conversation.setLastError("");
        } else {
            // Don't keep a dangling unanswered user message in history on failure.
            conversation.getHistory().remove(conversation.getHistory().size() - 1);
            conversation.setLastError(result.errorMessage());
        }

        conversation.trimTo(ConversationStore.maxHistoryMessages);
    }

    @Override
    public String toString(Event event, boolean debug) {
        return "send groq prompt " + promptExpr.toString(event, debug);
    }
}
