package com.mcserver.groqskript.elements;

import ch.njol.skript.doc.Description;
import ch.njol.skript.doc.Examples;
import ch.njol.skript.doc.Name;
import ch.njol.skript.doc.Since;
import ch.njol.skript.lang.Effect;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.util.Kleenean;
import com.mcserver.groqskript.ConversationStore;
import org.bukkit.event.Event;

@Name("Clear Groq History")
@Description("Wipes the remembered message history for a conversation (default: \"default\"), " +
        "so the next prompt starts a fresh conversation. Does not clear the system prompt.")
@Examples({
        "clear groq history",
        "clear groq history of \"%player%\""
})
@Since("1.0")
public class EffClearGroqHistory extends Effect {

    private Expression<String> idExpr;

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] exprs, int matchedPattern, Kleenean isDelayed, ParseResult parseResult) {
        idExpr = (Expression<String>) exprs[0];
        return true;
    }

    @Override
    protected void execute(Event event) {
        String id = "default";
        if (idExpr != null) {
            String parsedId = idExpr.getSingle(event);
            if (parsedId != null && !parsedId.isBlank()) {
                id = parsedId;
            }
        }
        ConversationStore.get(id).clearHistory();
    }

    @Override
    public String toString(Event event, boolean debug) {
        return "clear groq history";
    }
}
