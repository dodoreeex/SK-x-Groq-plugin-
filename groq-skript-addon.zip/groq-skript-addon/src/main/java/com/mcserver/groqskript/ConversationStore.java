package com.mcserver.groqskript;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Central lookup for conversations by id, e.g. a player's UUID string, a
 * player name, or any string the script chooses (default: "default").
 */
public class ConversationStore {

    private static final Map<String, Conversation> conversations = new ConcurrentHashMap<>();

    /** Config value, set once from config.yml when the plugin enables. */
    public static int maxHistoryMessages = 20;

    private ConversationStore() {
    }

    public static Conversation get(String id) {
        return conversations.computeIfAbsent(id, k -> new Conversation());
    }
}
