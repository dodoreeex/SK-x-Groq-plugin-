package com.mcserver.groqskript;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;

/**
 * Talks to Groq's OpenAI-compatible chat completions endpoint.
 * Uses the JDK's built-in HTTP client, so no extra dependency/shading is needed.
 */
public class GroqApiClient {

    private static final String ENDPOINT = "https://api.groq.com/openai/v1/chat/completions";

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    /** Simple outcome holder — exactly one of content/errorMessage is meaningful. */
    public record Result(boolean success, String content, String errorMessage) {
        public static Result ok(String content) {
            return new Result(true, content, "");
        }

        public static Result fail(String errorMessage) {
            return new Result(false, "", errorMessage);
        }
    }

    public Result chat(String apiKey, String model, String systemPrompt,
                        List<GroqMessage> history, double temperature, int timeoutSeconds) {

        if (apiKey == null || apiKey.isBlank() || apiKey.equals("YOUR-GROQ-API-KEY-HERE")) {
            return Result.fail("No Groq API key configured. Set 'api-key' in config.yml.");
        }

        JsonArray messages = new JsonArray();
        if (systemPrompt != null && !systemPrompt.isBlank()) {
            messages.add(messageJson("system", systemPrompt));
        }
        for (GroqMessage m : history) {
            messages.add(messageJson(m.getRole(), m.getContent()));
        }

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", messages);
        body.addProperty("temperature", temperature);

        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(ENDPOINT))
                    .timeout(Duration.ofSeconds(timeoutSeconds))
                    .header("Authorization", "Bearer " + apiKey)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                return Result.fail("Groq API returned HTTP " + response.statusCode() + ": " + extractErrorMessage(response.body()));
            }

            JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
            String content = json.getAsJsonArray("choices")
                    .get(0).getAsJsonObject()
                    .getAsJsonObject("message")
                    .get("content").getAsString();

            return Result.ok(content);

        } catch (java.net.http.HttpTimeoutException e) {
            return Result.fail("Request to Groq timed out after " + timeoutSeconds + "s.");
        } catch (IOException | InterruptedException e) {
            return Result.fail("Could not reach Groq API: " + e.getMessage());
        } catch (RuntimeException e) {
            return Result.fail("Unexpected response from Groq API: " + e.getMessage());
        }
    }

    private JsonObject messageJson(String role, String content) {
        JsonObject obj = new JsonObject();
        obj.addProperty("role", role);
        obj.addProperty("content", content);
        return obj;
    }

    private String extractErrorMessage(String body) {
        try {
            JsonObject json = JsonParser.parseString(body).getAsJsonObject();
            if (json.has("error") && json.getAsJsonObject("error").has("message")) {
                return json.getAsJsonObject("error").get("message").getAsString();
            }
        } catch (RuntimeException ignored) {
            // fall through to raw body
        }
        return body;
    }
}
