package com.mcserver.groqskript.elements;

import ch.njol.skript.doc.Description;
import ch.njol.skript.doc.Examples;
import ch.njol.skript.doc.Name;
import ch.njol.skript.doc.Since;
import ch.njol.skript.lang.Expression;
import ch.njol.skript.lang.SkriptParser.ParseResult;
import ch.njol.skript.lang.util.SimpleExpression;
import ch.njol.util.Kleenean;
import com.mcserver.groqskript.ConversationStore;
import org.bukkit.event.Event;

@Name("Last Groq Response")
@Description("The most recent successful response text from a conversation (default: \"default\"). " +
        "Empty if no prompt has succeeded yet.")
@Examples("send \"Groq says: %last groq response%\" to player")
@Since("1.0")
public class ExprLastGroqResponse extends SimpleExpression<String> {

    private Expression<String> idExpr;

    @Override
    @SuppressWarnings("unchecked")
    public boolean init(Expression<?>[] exprs, int matchedPattern, Kleenean isDelayed, ParseResult parseResult) {
        idExpr = (Expression<String>) exprs[0];
        return true;
    }

    @Override
    protected String[] get(Event event) {
        String id = "default";
        if (idExpr != null) {
            String parsedId = idExpr.getSingle(event);
            if (parsedId != null && !parsedId.isBlank()) {
                id = parsedId;
            }
        }
        return new String[]{ConversationStore.get(id).getLastResponse()};
    }

    @Override
    public boolean isSingle() {
        return true;
    }

    @Override
    public Class<? extends String> getReturnType() {
        return String.class;
    }

    @Override
    public String toString(Event event, boolean debug) {
        return "last groq response";
    }
}
