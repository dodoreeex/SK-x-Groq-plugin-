package com.mcserver.groqskript;

import ch.njol.skript.Skript;
import com.mcserver.groqskript.elements.EffClearGroqHistory;
import com.mcserver.groqskript.elements.EffSendGroqPrompt;
import com.mcserver.groqskript.elements.EffSetGroqSystemPrompt;
import com.mcserver.groqskript.elements.ExprGroqError;
import com.mcserver.groqskript.elements.ExprGroqHistory;
import com.mcserver.groqskript.elements.ExprLastGroqResponse;
import org.bukkit.plugin.java.JavaPlugin;

public class GroqChatPlugin extends JavaPlugin {

    private static GroqChatPlugin instance;
    private static final GroqApiClient apiClient = new GroqApiClient();

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();
        reloadConfig();
        ConversationStore.maxHistoryMessages = getConfig().getInt("max-history", 20);

        Skript.registerAddon(this);

        // Every effect/expression is registered explicitly here (no classpath
        // scanning), so this list is the single source of truth for what
        // syntax this addon provides.
        Skript.registerEffect(EffSendGroqPrompt.class,
                "send groq prompt %string% [(to|for) %-string%] [with model %-string%]");
        Skript.registerEffect(EffClearGroqHistory.class,
                "clear groq (history|conversation|memory) [(of|for) %-string%]");
        Skript.registerEffect(EffSetGroqSystemPrompt.class,
                "set groq system prompt [(of|for) %-string%] to %string%");

        Skript.registerExpression(ExprLastGroqResponse.class, String.class, ch.njol.skript.lang.ExpressionType.SIMPLE,
                "[the] last groq response [(of|for) %-string%]");
        Skript.registerExpression(ExprGroqHistory.class, String.class, ch.njol.skript.lang.ExpressionType.SIMPLE,
                "[the] groq (history|conversation) [(of|for) %-string%]");
        Skript.registerExpression(ExprGroqError.class, String.class, ch.njol.skript.lang.ExpressionType.SIMPLE,
                "[the] groq error [(of|for) %-string%]");

        getLogger().info("Groq Skript addon enabled — model: " + getConfig().getString("model"));
    }

    public static GroqChatPlugin getInstance() {
        return instance;
    }

    public static GroqApiClient getApiClient() {
        return apiClient;
    }

    public String getApiKey() {
        return getConfig().getString("api-key", "");
    }

    public String getDefaultModel() {
        return getConfig().getString("model", "openai/gpt-oss-20b");
    }

    public double getTemperature() {
        return getConfig().getDouble("temperature", 1.0);
    }

    public int getTimeoutSeconds() {
        return getConfig().getInt("timeout-seconds", 20);
    }
}
